import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-favorites-screen',
  templateUrl: './user-favorites-screen.component.html',
  styleUrls: ['./user-favorites-screen.component.css']
})
export class UserFavoritesScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
