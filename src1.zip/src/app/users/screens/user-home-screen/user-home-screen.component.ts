import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-home-screen',
  templateUrl: './user-home-screen.component.html',
  styleUrls: ['./user-home-screen.component.css']
})
export class UserHomeScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
