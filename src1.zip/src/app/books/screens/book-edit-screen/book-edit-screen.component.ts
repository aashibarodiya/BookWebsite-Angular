import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'book-edit-screen',
  templateUrl: './book-edit-screen.component.html',
  styleUrls: ['./book-edit-screen.component.css']
})
export class BookEditScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
