import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'book-manage-screen',
  templateUrl: './book-manage-screen.component.html',
  styleUrls: ['./book-manage-screen.component.css']
})
export class BookManageScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
