import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'favorite-book',
  templateUrl: './favorite-book.component.html',
  styleUrls: ['./favorite-book.component.css']
})
export class FavoriteBookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
