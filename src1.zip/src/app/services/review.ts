export interface Review{
    id?:number,
    reviewerName:string;
    title:string;
    details:string;
    rating:number;
    _id?:string;
}
