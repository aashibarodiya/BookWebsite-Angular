import { CustomDomainDirective } from './custom-domain.directive';

describe('CustomDomainDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomDomainDirective();
    expect(directive).toBeTruthy();
  });
});
