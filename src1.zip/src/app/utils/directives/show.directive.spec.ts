import { ShowDirective } from './show.directive';

xdescribe('ShowDirective', () => {
  it('should create an instance', () => {
    //const directive = new ShowDirective(null);
    //expect(directive).toBeTruthy();
  });
});
