import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'not-found-screen',
  templateUrl: './not-found-screen.component.html',
  styleUrls: ['./not-found-screen.component.css']
})
export class NotFoundScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
