import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'author-edit-screen',
  templateUrl: './author-edit-screen.component.html',
  styleUrls: ['./author-edit-screen.component.css']
})
export class AuthorEditScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
