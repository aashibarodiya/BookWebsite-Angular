import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'author-manage-screen',
  templateUrl: './author-manage-screen.component.html',
  styleUrls: ['./author-manage-screen.component.css']
})
export class AuthorManageScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
